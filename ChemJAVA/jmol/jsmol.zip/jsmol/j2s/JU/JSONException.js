Clazz.declarePackage ("JU");
Clazz.load (["java.lang.RuntimeException"], "JU.JSONException", null, function () {
c$ = Clazz.declareType (JU, "JSONException", RuntimeException);
});
